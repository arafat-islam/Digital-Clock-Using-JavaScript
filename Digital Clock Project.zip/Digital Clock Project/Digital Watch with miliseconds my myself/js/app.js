function StopWatch() {
    var fullTime = new Date();
    var hour = fullTime.getHours();
    var minute = fullTime.getMinutes();
    var second = fullTime.getSeconds();
    var miliSecond = fullTime.getMilliseconds();

    if(hour < 10 ) {
        hour = '0' + hour;
    }
    if(minute < 10 ) {
        minute = '0' + minute;
    }
    if(second < 10 ) {
        second = '0' + second;
    }
    if(miliSecond < 100 ) {
        miliSecond = '0' + miliSecond;
    }

    document.getElementById('hour').innerHTML = hour + ':';
    document.getElementById('minute').innerHTML = minute + ':';
    document.getElementById('second').innerHTML = second + ':';
    document.getElementById('miliSecond').innerHTML = miliSecond;
}

setInterval(StopWatch);




var fullTime = new Date();
var hour = fullTime.getHours();
var minute = fullTime.getMinutes();
var second = fullTime.getSeconds();
var miliSecond = fullTime.getMilliseconds();




var stopEvent = document.getElementById('stop');
stopEvent.addEventListener('click', stopTime);
function stopTime(e) {
    document.getElementById('hour1').innerHTML = hour + ':';
    document.getElementById('minute1').innerHTML = minute + ':';
    document.getElementById('second1').innerHTML = second + ':';
    document.getElementById('miliSecond1').innerHTML = miliSecond;

}


// var resetEvent = document.getElementById('reset').addEventListener('click',resetEvent);

// function resetEvent() {
//     document.getElementById('stop').removeEventListener('click', stopTime);
// }

$(document).ready(function() {
    
    $('#reset').click(function() {
        $('.container').toggle(2000)
    });


});