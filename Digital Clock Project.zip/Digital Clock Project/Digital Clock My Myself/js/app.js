setInterval(showTimer, 10);

function showTimer() {
    const fullTime = new Date();
    var hour = fullTime.getHours();
    var minute = fullTime.getMinutes();
    var second = fullTime.getSeconds();

    if(hour <= 9) {
        hour = '0' +  hour;
    }
    if(munite <= 9) {
        munite = '0' + minute;
    }
    if(second <= 9) {
        second = '0' + second;
    }


    document.getElementById('hour').innerHTML = hour + ':';
    document.getElementById('munite').innerHTML = minute + ':';
    document.getElementById('second').innerHTML = second;
}